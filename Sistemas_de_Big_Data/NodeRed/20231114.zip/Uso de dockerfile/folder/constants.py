#!/usr/bin/env python3
# -*- coding: utf-8 -*-

HOST = '0.0.0.0'
PORT = 8010